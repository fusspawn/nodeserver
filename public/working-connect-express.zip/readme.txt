Drop the contents of this folder into the root of the application and add the following dependency in package.json 

"qs": "*"



Example Package.json: 

{
  
 "name": "testing",
  
 "version": "0.0.0",
 
 "repository": {},
 
 "engines": {
  
    "node": "*"
  
 },
 
 "dependencies": {
   
	
	"mongodb": "*",

	"mongoose": "*",

	"jade": "*",

	"socket.io": "*",

	"qs": "*"
  
 }

} 